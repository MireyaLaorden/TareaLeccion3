package Leccion3.tarea1;

public interface Servicio {
	public void ejecutar();

}
