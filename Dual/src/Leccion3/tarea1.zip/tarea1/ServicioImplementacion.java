package Leccion3.tarea1;

public class ServicioImplementacion implements Servicio{

	@Override
	public void ejecutar() {
		System.out.println("Servicio ejecutado");
		
	}

}
